# Zelda NES Remake

# Weapon switching

press "c" to switch the weapon on the "z" key.

"x" -- sword
"z" -- secondary weapon

